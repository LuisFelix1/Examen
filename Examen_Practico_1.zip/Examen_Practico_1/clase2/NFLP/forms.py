from django import forms

from .models import jugador
from .models import estadio
from .models import equipo
from .models import equipob
from .models import posicion

class Formjugador(forms.ModelForm):
	class Meta:
		model = jugador
		fields = ["Name","Age","Position","Team"]

class Formequipo(forms.ModelForm):
	class Meta:
		model = equipo
		fields = ["Team","State","League"]

class Formestadio(forms.ModelForm):
	class Meta:
		model = estadio
		fields = ["Stadium","Location"]

class FormEquipob(forms.ModelForm):
	class Meta:
		model = equipob
		fields = ["Team"]

class Formposicion(forms.ModelForm):
	class Meta:
		model = posicion
		fields = ["Position"]