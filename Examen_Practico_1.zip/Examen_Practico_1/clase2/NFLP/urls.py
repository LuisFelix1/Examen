from django.urls import path

from django.views import generic

from NFLP import views

urlpatterns = [
	path('Main/', views.Main, name='Main_view'),
	path('Register_Player/',views.Register_Player.as_view(),name="Register_Player_view"),
	path('Register_Team/',views.Register_Team.as_view(),name="Register_Team_view"),
	path('Register_Stadium/',views.Register_Stadium.as_view(),name="Register_Stadium_view"),
	path('players/',views.players.as_view(),name="players_view"),
	path('splayers/<slug:Team>', views.splayers, name="splayers_view"),
	path('search_team/', views.search_team, name="search_team_view"),
	path('teams/',views.teams.as_view(),name="teams_view"),
	path('stadiums/',views.stadiums.as_view(),name="stadiums_view"),
	#path('list_tweet/', views.list_tweet, name="list_tweet") ,
	#as view para basado en vistas 
	#path('list_Tweet/', views.list_Tweet.as_view(), name="list_Tweet_view"),
	#path('retrieve_tweet/<int:id>', views.retrieve_tweet, name="retrieve_tweet_view"),
	#path('Retrieve_Tweet/<int:pk>', views.Retrieve_Tweet.as_view(), name="Retrieve_Tweet_view"),
	#path('create_tweet/', views.create_tweet, name="create_tweet_view"),
	#path('Create_Tweet/', views.Create_Tweet.as_view(), name="Create_Tweet_view"),
	#path('carousel_tweet/', views.carousel_tweet, name="carousel_tweet_view"),
	#path('Delete_Tweet/<int:pk>', views.Delete_Tweet.as_view(), name="Delete_Tweet_view"),
]