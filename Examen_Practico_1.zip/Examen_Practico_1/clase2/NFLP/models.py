from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError
from .validators import validate_content

# Create your models here.

class jugador(models.Model):
#A cada cambio en el modelo aplicamos makemigrations
    #user     
    #user = models.ForeignKey(settings.AUTH_USER_MODEL, default=1, on_delete=models.CASCADE)
    #content = models.TextField()
    #content = models.CharField(max_length=256, validators=[validate_content])
    #njugador = models.CharField(max_length=256)
    Name = models.CharField(max_length=256)
    Age = models.CharField(max_length=256)
    Position = models.CharField(max_length=256)
    Team = models.CharField(max_length=256)

class equipo(models.Model):
	Team = models.CharField(max_length=256)
	State = models.CharField(max_length=256)
	League = models.CharField(max_length=256)

class estadio(models.Model):
	Stadium = models.CharField(max_length=256)
	Location = models.CharField(max_length=256)
#Quitar y hacer makemigrations    
   # extra_field = models.CharField(max_length=24)
class equipob(models.Model):
    Team = models.CharField(max_length=256)

class posicion(models.Model):
    Position = models.CharField(max_length=256)

#Siempre lleva este parametro
    def __str__(self):
        return str(self.content)
