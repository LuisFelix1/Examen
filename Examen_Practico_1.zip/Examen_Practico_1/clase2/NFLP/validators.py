from django.core.exceptions import ValidationError


def validate_content(value):
    	content = value
    	if "XXX" in content.upper(): #content es una cadena, se pasa a mayuscula y luego se evalua
    		raise ValidationError("Content cannot publicated")
    	return content #ya que pase la validacion regresa el contenido