from django.apps import AppConfig


class NflpConfig(AppConfig):
    name = 'NFLP'
