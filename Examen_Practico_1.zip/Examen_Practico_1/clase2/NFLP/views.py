from django.shortcuts import render
from .forms import Formjugador
from .forms import Formequipo
from .forms import Formestadio
from .forms import FormEquipob
from .forms import Formposicion
from .models import equipob
from .models import posicion
from .models import jugador
from .models import estadio
from .models import equipo
from django.views import generic
# Create your views here.

#def retrieve_nflp(request, id=2):
#    queryset = nflp.objects.all()#tienen que ser campos unicos
#    context = {
#    	"NFLP": queryset
#    }
#    return render(request, "NFLP/retrieve_nflp.html", context)

def Main(request):
    return render(request, "NFLP/Main.html", {})


class Register_Player(generic.CreateView):
	template_name = "NFLP/register_player.html"
	model = jugador
	fields = ["Name","Age","Position","Team"]
	success_url = "/NFLP/players/"

def register_player(request):
	form = Formjugador(request.POST or None)
	context = {
		"form": form,
	}
	return render(request, "NFLP/register_player.html", context)

class Register_Team(generic.CreateView):
	template_name = "NFLP/register_team.html"
	model = equipo
	fields = ["Team","State","League"]
	success_url = "/NFLP/teams/"

def register_team(request):
	form = Formequipo(request.POST or None)
	context = {
		"form": form,
	}
	return render(request, "NFLP/register_team.html", context)

class Register_Stadium(generic.CreateView):
	template_name = "NFLP/register_stadium.html"
	model = estadio
	fields = ["Stadium","Location"]
	success_url = "/NFLP/stadiums/"

def register_stadium(request):
	form = Formestadio(request.POST or None)
	context = {
		"form": form,
	}
	return render(request, "NFLP/register_stadium.html", context)

class players(generic.ListView):
	template_name = "NFLP/players.html"
	queryset = jugador.objects.all()

def splayers(request, Team=""):
    queryset = Tweet.objects.get(Team=Team)#tienen que ser campos unicos
    context = {
    	"NFLP": queryset
    }
    return render(request, "NFLP/players", context)
	#queryset = jugador.objects.all()
	#return render(request, "NFLP/players.html", context)

class teams(generic.ListView):
	template_name = "NFLP/teams.html"
	queryset = equipo.objects.all()

class stadiums(generic.ListView):
	template_name = "NFLP/stadiums.html"
	queryset = estadio.objects.all()

#busquedaJugadores de x equipo

# class Splayers(generic.ListView):
# 	template_name = "NFLP/players.html"
# 	queryset = equipob.objects.filter(Name=request.POST.get('Team'))


# class Search_Team(generic.CreateView, generic.ListView):
# 	template_name = "NFLP/search_team.html"
# 	model = FormEquipob
# 	fields = ["Team"]
# 	success_url = "/NFLP/players/"

# def search_team(request):
# 	form = FormEquipob(request.POST or None)
# 	context = {
# 		"form": form,
# 	}
# 	queryset = jugador.objects.filter(Team=form.get)
# 	return render(request, "NFLP/players.html", context)

def search_team(request):
    return render(request, "NFLP/search_team.html", {})